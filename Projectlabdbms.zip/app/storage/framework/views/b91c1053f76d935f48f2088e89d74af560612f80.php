

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                    <a href="<?php echo e(route('account.create')); ?>" class="btn btn-success">เปิดบัญชี</a>
                </div>

                <div class="panel-heading">
                <table class="table">
                    <thead>
                    
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">ACC_No</th>
                        <th scope="col">ACC_Name</th>
                        <th scope="col">ACC_Surname</th>
                        <th scope="col">Balance</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo e($row->ACC_No); ?></td>
                        <td><?php echo e($row->ACC_Name); ?></td>
                        <td><?php echo e($row->ACC_Surname); ?></td>
                        <td><?php echo e($row->Balance); ?></td>
                        </tr>

                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views//account/index.blade.php */ ?>