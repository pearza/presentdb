

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                    <form method="post" action="<?php echo e(route('adduser_detail.update',$data->id)); ?>">
                        <!-- send data to function update in TypeController -->
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <table class="table">
                            <tr>
                                <td><label for="userd_id">รหัสประจำตัว</label></td>
                                <td><input type=text name="userd_id" value="<?php echo e($data->userd_id); ?>"></td>
                            </tr>
                            <tr>
                                <td><label for="userd_name">ชื่อ</label></td>
                                <td><input type=text name="userd_name" value="<?php echo e($data->userd_name); ?>"></td>
                            </tr>
                            <tr>
                                <td><label for="userd_surname">นามสกุล</label></td>
                                <td><input type="text" name="userd_surname" value="<?php echo e($data->userd_surname); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="userd_sex">เพศ</label></td>
                                <td> <select name="userd_sex">
                                        <option value="ชาย">ชาย</option>
                                        <option value="หญิง">หญิง</option>
                                       
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="userd_tel">เบอร์โทรศัพท์</label></td>
                                <td><input type="tel" name="userd_tel" value="<?php echo e($data->userd_tel); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="userd_status">เพศ</label></td>
                                <td> <select name="userd_status">
                                        <option value="นิสิต">นิสิต</option>
                                        <option value="อาจารย์">อาจารย์</option>
                                        <option value="อื่นๆ">อื่นๆ</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td colspan=2 align=center>
                                    <button class="btn btn-success" type="submit">ยืนยัน</button>
                                </td>
                            </tr>

                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/adduser_detail/edit.blade.php */ ?>