<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    img {
        display: block;
        margin-left: auto;
        margin-right: auto;
    }

    ,
</style>

<body>
    <?php if($data): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e($row->sp_img); ?>" alt="Paris" class="center" width="500" height="500">
    <h1 style="text-align:center;"> <?php echo e($row->sp_name); ?></h1><br>
    <h1 style="text-align:center;">จำนวนคงเหลือ: <?php echo e($row->sp_unit); ?></h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    ไม่พบข้อมูล
    <?php endif; ?>

</body>

</html>
<?php /* /app/resources/views/stock/search.blade.php */ ?>