

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <table class="table">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">userd_id</th>
                                <th scope="col">userd_name</th>
                                <th scope="col">userd_surname</th>
                                <th scope="col">userd_sex</th>
                                <th scope="col">userd_tel</th>
                                <th scope="col">userd_status</th>
                                <th scope="col" colspan=2>Operation</th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td><?php echo e($row->userd_id); ?></td>
                                <td><?php echo e($row->userd_name); ?></td>
                                <td><?php echo e($row->userd_surname); ?></td>
                                <td><?php echo e($row->userd_sex); ?></td>
                                <td><?php echo e($row->userd_tel); ?></td>
                                <td><?php echo e($row->userd_status); ?></td>
                                <td><a href="<?php echo e(route('adduser_detail.edit',$row->id)); ?>" class="btn btn-warning">Edit</a></td>
                            </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/adduser_detail/showtable.blade.php */ ?>