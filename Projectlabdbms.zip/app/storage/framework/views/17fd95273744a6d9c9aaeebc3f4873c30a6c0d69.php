

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                    <form method="post" action="<?php echo e(route('addsport.update',$data->id)); ?>">
                        <!-- send data to function update in TypeController -->
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <table class="table">
                            <tr>
                                <td><label for="type_id">ชนิดกีฬา</label></td>
                                <td>
                                    <select name="type_id">
                                        <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->type_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="sp_id">รหัสอุปกรณ์</label></td>
                                <td><input type=text name="sp_id" value="<?php echo e($data->sp_id); ?>"></td>
                            </tr>
                            <tr>
                                <td><label for="sp_img">รูปภาพ</label></td>
                                <td><input type="url" name="sp_img" value="<?php echo e($data->sp_img); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_name">ชื่ออุปกรณ์</label></td>
                                <td><input type="text" name="sp_name" value="<?php echo e($data->sp_name); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_brand">ยี่ห้อ</label></td>
                                <td><input type="text" name="sp_brand" value="<?php echo e($data->sp_brand); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_price">ราคา</label></td>
                                <td><input type="text" name="sp_price" value="<?php echo e($data->sp_price); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_buy">วันที่ซื้อ</label></td>
                                <td><input type=date name="sp_buy" value="<?php echo e($data->sp_buy); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_unit">จำนวน</label></td>
                                <td><input type=text name="sp_unit" value="<?php echo e($data->sp_unit); ?>"><br></td>
                            </tr>
                            <tr>
                                <td colspan=2 align=center>
                                    <button class="btn btn-success" type="submit">ยืนยัน</button>
                                </td>
                            </tr>

                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/addsport/edit.blade.php */ ?>