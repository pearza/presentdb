

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-13 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div>
                        <a href="<?php echo e(route('addborrow.create')); ?>" class="btn btn-success">เพิ่มการยืม</a>
                    </div>
                    <table  class="table table-hover"  >
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">รหัสการยืม</th>
                                <th scope="col">รหัสประจำตัวผู้ยืม</th>
                                <th scope="col">ชื่ออุปกรณ์</th>
                                <th scope="col">จำนวนการยืม</th>
                                <th scope="col">วันเวลาที่ยืม</th>
                                <th scope="col">สถานะ</th>
                                <th scope="col" colspan=2>Operation</th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td><?php echo e($row->borrow_id); ?></td>
                                <td><?php echo e($row->userd_id); ?></td>
                                <td><?php echo e($row->sp_name); ?></td>
                                <td><?php echo e($row->borrow_unit); ?></td>
                                <td><?php echo e($row->created_at); ?></td>
                                <td><?php echo e($row->borrow_status); ?></td>
                                <!-- route ไปที่ account and call function edit and update by . in file AccountController -->
                               
                                <!-- route ไปที่ account and call function destroy by . in file AccountController -->
                            </tr>

                        </tbody>
                       


                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/addborrow/return.blade.php */ ?>