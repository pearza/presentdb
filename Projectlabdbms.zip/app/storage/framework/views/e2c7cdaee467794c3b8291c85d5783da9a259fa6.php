

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                    <a href="<?php echo e(route('addborrow.create')); ?>" class="btn btn-success">เพิ่มชนิดอุปกรณ์</a>
                </div>
                <div class="panel-heading">
                    <table class="table">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">borrow_id</th>
                                <th scope="col">userd_id</th>
                                <th scope="col">type_id</th>
                                <th scope="col">borrow_unit</th>
                                <th scope="col">borrow_date</th>
                                <th scope="col">borrow_status</th>
                                <th scope="col" colspan=2>Operation</th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>

                                <th scope="row"><?php echo $i++; ?></th>
                                <td><?php echo e($row->borrow_id); ?></td>
                                <td><?php echo e($row->userd_id); ?></td>
                                <td><?php echo e($row->type_id); ?></td>
                                <td><?php echo e($row->borrow_unit); ?></td>
                                <td><?php echo e($row->borrow_date); ?></td>
                                <td><?php echo e($row->borrow_status); ?></td>
                                <!-- route ไปที่ account and call function edit and update by . in file AccountController -->
                                <!-- route ไปที่ account and call function destroy by . in file AccountController -->
                            </tr>

                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        ไม่พบข้อมล
                        <?php endif; ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/addborrow/showtable.blade.php */ ?>