<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDetail extends Model
{
    //
    public $table = "users_detail";

    protected $fillable = [
        'userd_id',
        'userd_name',
        'userd_surname',
        'userd_sex',
        'userd_tel',
        'userd_status'
    ];
}
