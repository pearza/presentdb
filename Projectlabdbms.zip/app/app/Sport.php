<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sport extends Model
{
    //
    protected $table = "sports";

    protected $fillable = [
        'sp_id',
        'sp_img',
        'sp_name',
        'sp_brand',
        'sp_price',
        'sp_buy',
        'sp_unit',
        'sport_id'
    ];
}
