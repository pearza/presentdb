<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Account; // เป็น เรียก Model มันคือชื่อ table ในฐานข้อมูล
use App\Sport;
use DB;


class ShowStockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function search(Request $request)
    {
        # $results = DB::select(
        # 'select Balance from Account where ACC_No=?',
        #  [$transfer->ACC_No_Source]
        # );
        $data = DB::select(
            'select * from sports where sp_name=?',
            [$request->search]
        );
        return view('stock.search', compact('data'));
    }
}
