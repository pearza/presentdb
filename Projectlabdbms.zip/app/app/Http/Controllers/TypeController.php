<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Account; // เป็น เรียก Model มันคือชื่อ table ในฐานข้อมูล
use App\Type;
class TypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Type::all();
        return view('addtype.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('addtype.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = new Type;

        $request->validate(
            [
            'type_id' => 'required|max:10',
            'type_name' => 'required|max:100',
            ]
        );
        $data->type_id = $request->type_id;
        $data->type_name = $request->type_name;
        $data->save();
        return redirect('addtype');
      
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // 
        $data = Type::find($id); // same --> select * from account = id
        return view("addtype.edit",compact('data')); // ส่งไปที่ view ใน account และต้องไปสร้างไฟล์ใน account ด้วยชื่อ edit
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       
        $data = Type::find($id); // or Type::findOrFail
        $request->validate(
            [
            'type_id' => 'required|max:10',
            'type_name' => 'required|max:100',
            ]
        );
        $data->type_id = $request->type_id;
        $data->type_name = $request->type_name;
        $data->update();

        return redirect('addtype');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
    }
}
