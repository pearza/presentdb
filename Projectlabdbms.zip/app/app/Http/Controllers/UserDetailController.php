<?php

namespace App\Http\Controllers;

use DB;
use App\UserDetail;
use Illuminate\Http\Request;

class UserDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = DB::table('users_detail')->select('users_detail.*')->get();
        return view('adduser_detail.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('adduser_detail.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $data = new UserDetail;
        $request->validate(
            [
                'userd_id' => 'required|max:100',
                'userd_name' => 'required|max:100',
                'userd_surname' => 'required|max:100',
                'userd_sex' => 'required|max:5',
                'userd_tel' => 'required|max:10',
                'userd_status' => 'required|max:100'
            ]
        );
        $data->userd_id = $request->userd_id;
        $data->userd_name = $request->userd_name;
        $data->userd_surname = $request->userd_surname;
        $data->userd_sex = $request->userd_sex;
        $data->userd_tel = $request->userd_tel;
        $data->userd_status = $request->userd_status;
        $data->save();
        $data = DB::table('users_detail')->select('users_detail.*')->get();
        return view('adduser_detail.index', compact('data'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UserDetail  $userDetail
     * @return \Illuminate\Http\Response
     */
    public function show($userDetail)
    { }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UserDetail  $userDetail
     * @return \Illuminate\Http\Response
     */
    public function edit($userDetail)
    {
        //
        $data = UserDetail::find($userDetail); // same --> select * from account = id
        return view("adduser_detail.edit", compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserDetail  $userDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $userDetail)
    {
        //
        $data = UserDetail::find($userDetail);
        $request->validate(
            [
                'userd_id' => 'required|max:100',
                'userd_name' => 'required|max:100',
                'userd_surname' => 'required|max:100',
                'userd_sex' => 'required|max:5',
                'userd_tel' => 'required|max:10',
                'userd_status' => 'required|max:100'
            ]
        );
        $data->userd_id = $request->userd_id;
        $data->userd_name = $request->userd_name;
        $data->userd_surname = $request->userd_surname;
        $data->userd_sex = $request->userd_sex;
        $data->userd_tel = $request->userd_tel;
        $data->userd_status = $request->userd_status;
        $data->update();
        return redirect('adduser_detail');
       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UserDetail  $userDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
    }
}
