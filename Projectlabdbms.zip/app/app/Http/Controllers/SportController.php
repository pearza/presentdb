<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Account; // เป็น เรียก Model มันคือชื่อ table ในฐานข้อมูล
use App\Sport;
use Illuminate\Support\Facades\Date;
use Faker\Provider\ka_GE\DateTime;
use DB;


class SportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::table('sports')
            ->join('types', 'types.id', '=', 'sports.type_id')
            ->select('sports.*', 'types.type_name')
            ->get();
        return view('addsport.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = DB::table('sports')->select('sports.*')->get();
        $data2 = DB::table('types')->select('types.*')->get();
        return view('addsport.create', compact('data', 'data2'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $data = new Sport;
        $request->validate(
            [
                'sp_id' => 'required|max:100',
                'sp_img' => 'required|max:1000',
                'sp_name' => 'required|max:100',
                'sp_brand' => 'required|max:100',
                'sp_price' => 'required|max:100',
                'sp_buy' => 'required',
                'sp_unit' => 'required',
                'type_id' => 'required',

            ]
        );
        $data->sp_id = $request->sp_id;
        $data->sp_img = $request->sp_img;
        $data->sp_name = $request->sp_name;
        $data->sp_brand = $request->sp_brand;
        $data->sp_price = $request->sp_price;
        $data->sp_buy = $request->sp_buy;
        $data->sp_unit = $request->sp_unit;
        $data->type_id = $request->type_id;
        $data->save();
        return redirect('addsport');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = DB::table('sports')
            ->join('types', 'types.id', '=', 'sports.type_id')
            ->select('sports.*', 'types.type_name')
            ->get();
        return view('addsport.stack', compact('data'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // 
        $data = Sport::find($id); // same --> select * from account = id
        $data2 = DB::table('types')->select('types.*')->get();
        return view("addsport.edit", compact('data', 'data2')); // ส่งไปที่ view ใน account และต้องไปสร้างไฟล์ใน account ด้วยชื่อ edit

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = Sport::find($id);
        $request->validate(
            [
                'sp_id' => 'required|max:100',
                'sp_img' => 'required|max:100',
                'sp_name' => 'required|max:100',
                'sp_brand' => 'required|max:100',
                'sp_price' => 'required|max:100',
                'sp_buy' => 'required',
                'sp_unit' => 'required',
                'type_id' => 'required',


            ]
        );
        $data->sp_id = $request->sp_id;
        $data->sp_img = $request->sp_img;
        $data->sp_name = $request->sp_name;
        $data->sp_brand = $request->sp_brand;
        $data->sp_price = $request->sp_price;
        $data->sp_buy = $request->sp_buy;
        $data->sp_unit = $request->sp_unit;
        $data->type_id = $request->type_id;
        $data->update();
        # $data2 = DB::table('types')->select('types.*')->get();
        #return view('addsport.index', compact('data'));
        return redirect('addsport');
    }
   
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    { }
}
