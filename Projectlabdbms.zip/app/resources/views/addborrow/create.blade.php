@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                    <form method="post" action="{{ route('addborrow.store') }}">
                        {{ csrf_field() }}
                        <table class="table">

                            <tr>
                                <td><label for="borrow_id">รหัสการยืม</label></td>
                                <td><input type=text name="borrow_id"></td>
                            </tr>
                            <tr>
                                <td><label for="userd_id">รหัตประจำตัวผูัยืม</label></td>
                                <td>
                                    <select name="userd_id">
                                        @foreach($data2 as $row)
                                        <option value="{{$row->id}}">{{ $row->userd_id}}</option>
                                        @endforeach
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="sport_id">ชื่ออุปกรณ์</label></td>
                                <td>
                                    <select name="sport_id">
                                        @foreach($data3 as $row)
                                        <option value="{{$row->id}}">{{ $row->sp_name}}</option>
                                        @endforeach
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="borrow_unit">จำนวน</label></td>
                                <td><input type="text" name="borrow_unit"><br></td>
                            </tr>
                            <input type="hidden" name="borrow_status" value="ยืม">
                            <tr>
                                <td colspan=2 align=center>
                                    <button class="btn btn-success" type="submit">ยืนยัน</button>
                                </td>
                            </tr>

                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection