@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                    <a href="{{ route('addsport.create') }}" class="btn btn-success">เพิ่มชนิดอุปกรณ์</a>
                </div>
              
                <div class="panel-heading">

                    <table class="table">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">ชื่อประเภทกีฬา</th>
                                <th scope="col">รหัสอุปกรณ์</th>
                                <th scope="col">รูปภาพ</th>
                                <th scope="col">ชื่ออุปกรณ์</th>
                                <th scope="col">ยี่ห้อ</th>
                                <th scope="col">ราคา</th>
                                <th scope="col">วันที่ซื้อ</th>
                                <th scope="col">จำนวน</th>
                                <th scope="col" colspan=2>Operation</th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        @if($data)
                        @foreach($data as $row)
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td>{{ $row->type_name}}</td>       
                                <td>{{ $row->sp_id}}</td>
                                <td><img src="{{ $row->sp_img}}" width="50" height="40"></td>
                                <td>{{ $row->sp_name}}</td>
                                <td>{{ $row->sp_brand}}</td>
                                <td>{{ $row->sp_price}}</td>
                                <td>{{ $row->sp_buy}}</td>      
                                <td>{{ $row->sp_unit}}</td>               
                                <!-- route ไปที่ account and call function edit and update by . in file AccountController -->
                                <td><a href="{{ route('addsport.edit',$row->id)}}" class="btn btn-warning">Edit</a></td>
                                <!-- route ไปที่ account and call function destroy by . in file AccountController -->
                            </tr>
                        </tbody>
                        @endforeach
                        @else
                        ไม่พบข้อมูล
                        @endif
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection