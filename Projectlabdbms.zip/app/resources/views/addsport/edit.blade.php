@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                    <form method="post" action="{{ route('addsport.update',$data->id) }}">
                        <!-- send data to function update in TypeController -->
                        @csrf
                        @method('PUT')
                        <table class="table">
                            <tr>
                                <td><label for="type_id">ชื่อประเภทกีฬา</label></td>
                                <td>
                                    <select name="type_id">
                                        @foreach($data2 as $row)
                                        <option value="{{$row->id}}">{{ $row->type_name }}</option>
                                        @endforeach
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="sp_id">รหัสอุปกรณ์</label></td>
                                <td><input type=text name="sp_id" value="{{ $data->sp_id }}"></td>
                            </tr>
                            <tr>
                                <td><label for="sp_img">รูปภาพ</label></td>
                                <td><input type="url" name="sp_img" value="{{ $data->sp_img }}"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_name">ชื่ออุปกรณ์</label></td>
                                <td><input type="text" name="sp_name" value="{{ $data->sp_name }}"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_brand">ยี่ห้อ</label></td>
                                <td><input type="text" name="sp_brand" value="{{ $data->sp_brand }}"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_price">ราคา</label></td>
                                <td><input type="text" name="sp_price" value="{{ $data->sp_price }}"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_buy">วันที่ซื้อ</label></td>
                                <td><input type=date name="sp_buy" value="{{ $data->sp_buy}}"><br></td>
                            </tr>
                            <tr>
                                <td><label for="sp_unit">จำนวน</label></td>
                                <td><input type=text name="sp_unit" value="{{ $data->sp_unit }}"><br></td>
                            </tr>
                            <tr>
                                <td colspan=2 align=center>
                                    <button class="btn btn-success" type="submit">ยืนยัน</button>
                                </td>
                            </tr>

                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection