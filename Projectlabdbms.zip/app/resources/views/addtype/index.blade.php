@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                    <a href="{{ route('addtype.create') }}" class="btn btn-success">เพิ่มชนิดอุปกรณ์</a>
                </div>

                <div class="panel-heading">

                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">รหัสประเภทกีฬา</th>
                                <th scope="col">ชื่อประเภทกีฬา</th>
                                <th scope="col" colspan=2>Operation</th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        @foreach($data as $row)
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td>{{ $row->type_id}}</td>
                                <td>{{ $row->type_name}}</td>
                                <!-- route ไปที่ account and call function edit and update by . in file AccountController -->
                                <td><a href="{{ route('addtype.edit',$row->id)}}" class="btn btn-warning">Edit</a></td>
                                <!-- route ไปที่ account and call function destroy by . in file AccountController -->
                            </tr>
                        </tbody>
                        @endforeach
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection