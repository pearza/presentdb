@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                    <a href="{{ route('adduser_detail.create') }}" class="btn btn-success">เพิ่มข้อมูลผู้มายืม</a>
                </div>
                <div class="panel-heading">
                    <table class="table">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">รหัสประจำตัว</th>
                                <th scope="col">ชื่อ</th>
                                <th scope="col">นามสกุล</th>
                                <th scope="col">เพศ</th>
                                <th scope="col">เบอร์โทรศัพท์</th>
                                <th scope="col">สถานะ</th>
                                <th scope="col" colspan=2>Operation</th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        @foreach($data as $row)
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td>{{ $row->userd_id}}</td>
                                <td>{{ $row->userd_name}}</td>
                                <td>{{ $row->userd_surname}}</td>
                                <td>{{ $row->userd_sex}}</td>
                                <td>{{ $row->userd_tel}}</td>
                                <td>{{ $row->userd_status}}</td>
                                <!-- route ไปที่ account and call function edit and update by . in file AccountController -->
                                <td><a href="{{ route('adduser_detail.edit',$row->id)}}" class="btn btn-warning">Edit</a></td>
                                <!-- route ไปที่ account and call function destroy by . in file AccountController -->
                            </tr>
                        </tbody>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection