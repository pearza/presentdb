@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                    <form method="post" action="{{ route('adduser_detail.store') }}">
                        {{ csrf_field() }}
                        <table class="table">
                        <tr>
                                <td><label for="userd_id">รหัสประจำตัว</label></td>
                                <td><input type=text name="userd_id"></td>
                            </tr>
                            <tr>
                                <td><label for="userd_name">ชื่อ</label></td>
                                <td><input type=text name="userd_name"></td>
                            </tr>
                            <tr>
                                <td><label for="userd_surname">นามสกุล</label></td>
                                <td><input type="text" name="userd_surname"><br></td>
                            </tr>
                            <tr>
                                <td><label for="userd_sex">เพศ</label></td>
                                <td> <select name="userd_sex">
                                        <option value="ชาย">ชาย</option>
                                        <option value="หญิง">หญิง</option>
                
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="userd_tel">เบอร์โทรศัพท์</label></td>
                                <td><input type="tel"   name="userd_tel"><br></td>
                            </tr>
                            <tr>
                                <td><label for="userd_status">สถานะผู้ยืม</label></td>
                                <td> <select name="userd_status">
                                        <option value="นิสิต">นิสิต</option>
                                        <option value="อาจารย์">อาจารย์</option>
                                        <option value="บุคลากร">บุคลากร</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td colspan=2 align=center>
                                    <button class="btn btn-success" type="submit">ยืนยัน</button>
                                </td>
                            </tr>

                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection