@extends('layouts.app')
<style>
    
    body,html {
        background-image: url("https://images.pexels.com/photos/163444/sport-treadmill-tor-route-163444.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
        background-size: 100%;
        background-repeat: no-repeat;
    
    }
</style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">ระบบยืม-คืนอุปกรณ์กีฬา</div>

                <div class="card-body">
                    <a href="{{ route('addtype.index') }}" class="btn btn-outline-secondary" role="button">เพิ่มชนิดอุปกรณ์กีฬา</a>
                    <a href="{{ route('addsport.index') }}" class="btn btn-outline-secondary" role="button">เพิ่มอุปกรณ์กีฬา</a>
                    <a href="{{ route('addborrow.index') }}" class="btn btn-outline-secondary" role="button">การยืมอุปกรณ์กีฬา</a>
                    <a href="{{ route('adduser_detail.index') }}" class="btn btn-outline-secondary" role="button">เพิ่มข้อมูลผู้ยืม</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection